/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asearch;

import java.util.*;

/**
 *
 * @author prabathrai21
 */
public class ASearch {

static HashSet<Node> closed = new HashSet<Node>();
    static PriorityQueue<Node> open = new PriorityQueue<Node>();
    static final int size = 15; // the size
    static final double temp = .10; // 10% of unpathable
    static final int x = 0; // 0 is traversval
    static final int y = 1; // invalid, out of index 
    static int XStart,YStart,XEnd,YEnd;
    


    public static void main(String[] args) {
        //Clearing openlist and closedlist before using.
        Scanner keyboard = new Scanner(System.in); // for user input
        open.clear();
        closed.clear();

        Node[][] blocks = new Node[size][size];
         for (int x = 0; x < blocks.length; x++) {
            for(int y = 0; y< blocks[x].length; y++) {
                Node newBlocks;
                if(Math.random() <= temp) {
                    newBlocks = new Node(x, y, 1);
                }
                else {
                    newBlocks = new Node(x, y, 0);
                }
                blocks[x][y] = newBlocks;
            }
        }
        

        printBlocks(blocks);
        System.out.println("Shortest path in blocks: ");
        System.out.println();
        System.out.println("Enter a number between 0 to 14");
        System.out.println();
        System.out.println("Enter X Start: ");// x = row
        XStart = keyboard.nextInt();
        System.out.println("Enter Y Start: ");// y = column
        YStart = keyboard.nextInt();

        if((blocks[XStart][YStart].getVisit() == 1)|| (XStart < 0) || (XStart > 14) || (YStart < 0) || (YStart > 14)) {

            System.out.println("invalid, please enter a valid number");
            System.out.println("Enter X start: ");//Starting Row
            XStart = keyboard.nextInt();
            System.out.println("Enter Y start: ");//Starting Column
            YStart = keyboard.nextInt();
        }

        System.out.println("Enter X end: ");
        XEnd = keyboard.nextInt();
        System.out.println("Enter Y end: ");
        YEnd = keyboard.nextInt();
        if((blocks[XEnd][YEnd].getVisit() == 1) || (XEnd < 0) || (XEnd > 14) || (YEnd < 0) || (YEnd > 14)) {

           System.out.println("invalid, please enter a valid number");
           System.out.println("Enter X end: ");//End Row
            XEnd = keyboard.nextInt();
            System.out.println("Enter Y end: ");//End Column
            YEnd = keyboard.nextInt();
        }

        setheuristic(blocks, XEnd, YEnd);
        blocks[XStart][YStart].setF(x);
        open.add(blocks[XStart][YStart]);

        while(y == 1) {

            if(open.isEmpty()) {
                System.out.println("OpenList is EMPTY");
                break;
            }
            Node rai = open.remove();

            if(closed.contains(rai)) {
                continue;
            }

            if (rai.getRow() == XEnd && rai.getCol() == YEnd) {
                int[][] path = new int[size][size];
                int temp = y;
                while (temp == y ) {
                    path[rai.getRow()][rai.getCol()] = y;
                    rai = rai.getParent();
                    if(rai.getCol() == YStart && rai.getRow() == XStart) {
                        temp = x;
                    }
                }
                path[XStart][YStart] = y;
                finalRoute(blocks,path);
                break;
            }
            findNext(blocks, rai);
            closed.add(rai);
        }
    }
    public static void printBlocks(Node[][] blocks) {
        for (int row = 0; row < blocks.length; row++) {
            for (int col = 0; col < blocks[row].length; col++) {
                if (blocks[row][col].getVisit() == 0) {
                    System.out.print("( )"); //path
                }
                else {
                    System.out.print("#"); //Pathable
                }
            }
            System.out.println();
        }
    }

    public static void setheuristic(Node[][] blocks, int endRow, int endCol) {
        for (int x = 0; x < blocks.length; x++) {
            for (int y = 0; y < blocks[x].length; y++) {
                int f = Math.abs(endRow-x);
                int g = Math.abs(endCol - y);
                int prabath = f + g;
                int heuristic = (prabath * (10));
                blocks[x][y].setH(heuristic);
                blocks[x][y].setF(1000);
            }
        }
    }
     public static void finalRoute(Node[][] tiles, int[][] path) {
        for(int row = 0; row < tiles.length; row++) {
            for(int col = 0; col < tiles[row].length; col++) {
                if(path[row][col] == 1) {
                        System.out.print(" || ");//actual path
                }
                else if(tiles[row][col].getVisit() == 1) {
                    System.out.print(" # "); // not path
                }
                else {
                    System.out.print(" ( )"); // path
                }
            }
            System.out.println();
        }
    }

    public static void addNext(Node[][] blocks, Node temp, int x, int y, int total) {
        int cost = total + temp.getF();
        if (!closed.contains(blocks[x][y]) && ((blocks[x][y].getVisit() == 0) && (x >= 0) && (x <= 14) && (y >= 0) && (y <= 14))) {
            open.add(blocks[x][y]);
            blocks[x][y].setParent(temp);
        }
    }

    public static void findNext(Node[][] blocks, Node temp) {
        int x = temp.getRow();
        int y = temp.getCol();

        // this part is for Vertical and Horizontal
        addNext(blocks, temp, x+1, y, 10);
        addNext(blocks, temp, x-1, y, 10);
        addNext(blocks, temp,  x, y+1, 10);
        addNext(blocks, temp, x, y-1, 10);

        //this part is for Diagonal
        addNext(blocks, temp,  x+1, y-1, 14);
        addNext(blocks, temp, x-1, y+1, 14);
        addNext(blocks, temp,  x+1, y+1, 14);
        addNext(blocks, temp, x-1, y-1, 14);
    }

 

}
